from django.apps import AppConfig


class ProjetoFinancasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'projeto_financas'
