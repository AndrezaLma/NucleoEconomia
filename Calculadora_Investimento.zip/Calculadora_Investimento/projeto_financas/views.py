from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    if request.method =="GET":
        nome='caio'
        return render(request,'home.html',{'nome': nome})
    elif request.method == "POST":
        return HttpResponse('Fui chamando')


